#include "mbed.h"

DigitalIn mybutton(USER_BUTTON);
DigitalOut myled(LED1);
Serial pc(SERIAL_TX, SERIAL_RX);

int main() {
    while(1) {   
        if (mybutton == 0) {
            myled = !myled;
            wait(0.1);
        }
        myled = !myled;
        wait(0.5);
    }
}
         


