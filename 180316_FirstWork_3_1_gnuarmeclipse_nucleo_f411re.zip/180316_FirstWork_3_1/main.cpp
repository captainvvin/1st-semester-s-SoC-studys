#include "mbed.h"

PwmOut mypwm(PWM_OUT);

DigitalIn mybutton(USER_BUTTON);  // USER_BUTTON 에 해당하는 Input
DigitalIn InputBoard(D4);         // 보드에 있는 D4 포트에서 입력받음
DigitalOut myled(LED1);           // LED1 을통해 보드간에 입/출력을 알아보기 위함입니다.
DigitalOut OutputBoard(D2);       // 보드에 있는 D2 포트에서 출력합니다.

int main() {
    int count=0;     // 보드에서 USER_BUTTON을 눌렀을때, 상태를 저장하기위한 변수 count 입니다.
    OutputBoard=0;   // Normal한 상태에서의 OutputBoard의 상태는 0 입니다.
    myled=0;         // 마찬가지로 Normal한 상태에서의 myled의 상태는 0 입니다.
    while(1) {
        if(mybutton == 0) count++; // USER_BUTTON을 눌렀을때, count변수값을 1 증가 시킵니다.
        if(count == 2) {           // count가 2가 되면 아래의 문을 실행합니다.
            OutputBoard=1;         // D2포트를 통해 1의 출력을 발생시킵니다.
            wait(3);               // 이 3초동안 1의 출력을 발생시키고
            OutputBoard=0;         // 다시 출력을 0 값으로 초기화 시킵니다.
            count=0;               // 2로 카운트 되었던 count변수의 값을 0으로 초기
        }
        if(InputBoard == 1) {      // D4포트로 1의 입력이 들어온경우
            myled = !myled;        // myled의 상태를 반전시킵니다.
            wait(0.1);             // 0.1초동안 (즉 D4를 통해 입력이 1 들어 온경우 LED가 0.1초마다 점멸하게 됩니다.)
        }
        else {                     // 그 외의 아무런 입.출력이 없는 경우
            myled = !myled;        // myled의 상태를 반전시킵니다.
            wait(0.5);             // 0.5초동안
        }
    }
}