#include "mbed.h"

Serial pc(USBTX, USBRX);
PwmOut led(PB_13);
float brightness=1.0;

int main() {
    pc.printf("Control of LED dimmer by host terminal\n\r");
    pc.printf("Press 'u' = brighter, 'd' = dimmer\n\r"); // 실행창에 프린트
    
    while(1) {
        char c = pc.getc(); // 문자를 입력 받음
        wait(0.001);
        
        if((c == 'u')&&(brightness < 1.0f)) { // u를 입력했을 때, brightness가 1.0f 보다 작다면
            brightness = brightness+0.05f; // brightness 를 0.05 상승
            led = brightness;              // brightness 값을 led에 대입시킴
        }
        
        if((c == 'd')&&(brightness > 0.0f)) { // d를 입력했을 때, biightness가 0.0f 보다 크다면
            brightness = brightness-0.05f; // brightness 를 0.05 감소
            led = brightness;              // brightness 값을 led에 대입시킴
        }
    
    pc.printf("%c %1.3f \n \r",c,brightness); // 현재 brightness값을 print
    }
}