#include "stdio.h"
#include "mbed.h"
#include "SPI_TFT_ILI9341.h"
#include "string"
#include "Arial12x12.h"
#include "Arial24x23.h"
#include "Arial28x28.h"
#include "font_big.h"

DigitalOut trigger(D2); // sonar trigger pin set
DigitalIn echo(A1);     // sonar echo pin set
 
// the TFT is connected to SPI pin 5-7
SPI_TFT_ILI9341 TFT(PC_12, PC_11, PC_10, PA_4, PA_10, PB_8,"TFT"); // mosi, miso, sclk, cs, reset, dc
int distance = 0; // initialize distance value
int correction = 0; // initialize correction value
Timer sonar; // set sonar's timer
int main() {
    // draw some graphics
    TFT.cls();
 
    TFT.line(120,0,120,320,White);
    TFT.line(0,0,240,0,White);
    TFT.line(0,64,240,64,White);
    TFT.line(0,128,240,128,White);
    TFT.line(0,196,240,196,White);
    TFT.line(0,256,240,256,White);
    TFT.line(0,320,240,320,White);
    
    sonar.reset(); // reset sonar timer
    sonar.start(); // start sonar timer
    while (echo==2){}; // min software polling delay to read echo pin
    sonar.stop(); // stop sonar timer
    correction=sonar.read_us(); // read sonar exe.time
    
    while(1){
        trigger=1; // trigger set
        sonar.reset(); // sonar timer reset
        wait_us(10.0); // send 10us pulse to trigger pin
        trigger = 0; // trigger set
        
        while(echo ==0){}; // while echo is high
        sonar.start(); // timer start
        
        while(echo==1){}; // wait for echo is low
        sonar.stop(); // timer stop
        ::distance = (sonar.read_us()-correction)/58.0; // formula about calc distance
        
        TFT.fillcircle(120,::distance,8,Red); // print a distance that shape of circle on LCD
        wait(0.5f);
        TFT.fillcircle(120,::distance,8,Black); // draw a line on LCD
        TFT.line(120,0,120,320,White);
        TFT.line(0,0,240,0,White);
        TFT.line(0,64,240,64,White);
        TFT.line(0,128,240,128,White);
        TFT.line(0,196,240,196,White);
        TFT.line(0,256,240,256,White);
        TFT.line(0,320,240,320,White);
        wait(0.5f);
    }
}