#include "mbed.h"
 
PwmOut mypwm(PC_9); // PC_9에서 출력을 발생시킴
 
int main() {
    while(1) {
        mypwm = mypwm+0.05f; // mypwm값을 0.05증가 시킨다
        wait(0.2); // 0.2초마다
        if(mypwm==1.0f) { //mypwm값이 1.0이 된다면
            mypwm=0; // 0으로 초기화시킨다
        }
    }
}