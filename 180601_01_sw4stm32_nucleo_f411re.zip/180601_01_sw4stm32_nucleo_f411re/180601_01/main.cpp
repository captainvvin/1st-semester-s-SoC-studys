#include "mbed.h"

Semaphore two_slots(3); // 세마포 카운트를 2,3으로 설정
Thread t2;
Thread t3;

void test_thread(void const *name){
    while(true){
        two_slots.wait(); // Semaphore wait
        printf("%s\n\r", (const char*)name); // USB RX,TX를 통해 프린
        wait(1);
        two_slots.release(); // Semaphore release
    }
}

int main(){
    t2.start(callback(test_thread, (void *)"Th 2")); // Thread start & Print
    t3.start(callback(test_thread, (void *)"Th 3"));
    test_thread((void*)"Th 1");
}