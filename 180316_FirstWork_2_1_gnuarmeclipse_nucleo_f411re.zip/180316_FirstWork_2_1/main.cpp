#include "mbed.h"

PwmOut mypwm(PWM_OUT);

DigitalIn mybutton(USER_BUTTON);
DigitalOut freq(D7);   // D7번 핀에서 출력을 발생시킵니다.

int main() {
    while(1) {
        if (mybutton == 0) { // USER_BUTTON이 눌러져있을경우
        freq = !freq;
        wait_us(625); // 800Hz에 해당하는 출력파형을 발생시킵니다.
        }
        else {
        freq = !freq;  // DigitalOut의 상태를 반전 시킵니다.
        wait(0.00125);
        } 
  }
}