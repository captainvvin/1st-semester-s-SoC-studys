#include"mbed.h"
#include"TextLCD.h"

Serial pc(USBTX,USBRX);  
TextLCD lcd(PC_10, PC_11,PC_12,PA_13,PA_14,PA_15);
AnalogIn Ain(PB_0);
float ADCdata;

int main() {
    pc.baud(115200); //초당 펄스 115200 방출
    while(1) {
        ADCdata=Ain.read(); // ADC데이터를 AnalogIn받은 핀에서 정보를 읽어들인다
        
        lcd.cls();
        
        lcd.locate(0,0); // LCD의 어느 부분에 자료를 출력할것인지 설정
        lcd.printf("Radian : %f\n",ADCdata*360.f); // 가변저항의 각도 변화를 표시
        wait(0.5f); 
    }    
}