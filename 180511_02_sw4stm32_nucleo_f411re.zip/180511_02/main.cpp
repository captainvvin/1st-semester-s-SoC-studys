#include "mbed.h"

DigitalOut B_LED(PC_10);
DigitalOut G_LED(PC_11);
DigitalOut R_LED(PC_12);
DigitalOut led1(LED1);
InterruptIn SW(USER_BUTTON);

int main()
{
    while(true){
        B_LED = !B_LED;
        wait(0.5);
        B_LED = !B_LED;
        G_LED = !G_LED;
        wait(0.5);
        B_LED = !B_LED;
        wait(0.5);
        B_LED = !B_LED;
        G_LED = !G_LED;
        R_LED = !R_LED;
        wait(0.5);
        B_LED = !B_LED;
        wait(0.5);
        B_LED = !B_LED;
        G_LED = !G_LED;
        wait(0.5);
        B_LED = !B_LED;
        wait(0.5);
        B_LED = !B_LED;
        G_LED = !G_LED;
        R_LED = !R_LED;
        wait(0.5);
    }
}