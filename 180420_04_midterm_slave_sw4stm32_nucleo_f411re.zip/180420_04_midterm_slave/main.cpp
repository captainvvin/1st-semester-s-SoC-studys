#include "mbed.h"

DigitalOut trigger(D4);
DigitalIn echo(A1);  // trigger & echo pin set
Serial uart1(PA_9, PA_10); // set uart1 pin
Serial pc(SERIAL_TX,SERIAL_RX);
PwmOut myled(PC_9);
PwmOut buzzer(PC_8); // myled & buzzer pin set
int distance = 0;
int correction = 0; 
Timer sonar;

void led_on(){
    myled=1;
}
void led_off(){
    myled=0;
}
void dim_up() {
    myled=myled+0.2f; // increase myled value 0.2 per input
    wait(0.1);
    if(myled==1.0f){ // when myled value is 1.0f
        myled=1; // fix myled value when increase
    }
}
void dim_down() {
    myled=myled-0.2f; // decrease my led value 0.2 per input
    wait(0.1);
    if(myled==0.0f) { // when myled value is 0.0f
        myled=0; // fix myled value when decrease
    }
}
void Buzzer(){ 
        for(int j = 0; j<3; j++) {
        wait(0.3); 
        buzzer = 1.0;
        wait(0.3);
        buzzer = 0; // buzzer on per 0.3sec three times
        }
}
void SONIC(){
    int n = 0;
    wait(3);
    pc.baud(9600);
    sonar.reset(); // timer reset
    sonar.start(); // timer start
    while (echo==2){};
    sonar.stop(); // timer stop
    correction=sonar.read_us(); // Approcimate software overhead time
    pc.printf("Approcimate software overhead timer delay is %d uS\n\r",correction);
    while(n<3){ // because we want check distance three time
        trigger=1;
        sonar.reset();
        wait_us(10.0);
        trigger = 0;
        while(echo ==0){}; // wait until echo value is High
        sonar.start();
        while(echo==1){}; // wait until echo value is Low
        sonar.stop();
        distance = (sonar.read_us()-correction)/58.0; // formula of calculate distance
        pc.printf("Distance = %d cm\n\n\r",distance); // print distance on Tera Term
        uart1.putc(distance); // transport distance value to other board
        wait(1.0f);
        n++; // because while
        }
}
 
int main(){
     char Baeyeoul[100];
     char ray[100];
     int token;
     while(1){
         for(int i=0;i<5;i++) {
            Baeyeoul[i]=uart1.getc(); // sending message is saved on Baeyeoul[] array
            wait(0.1);
            pc.printf("%x ",Baeyeoul[i]);
         
            if(Baeyeoul[i]==0xE1) {   
                token=1; // set token parameter to true
            }
            else if(Baeyeoul[i]==0xFF) {
                token=0; // set token parameter to false
            }
        
            if(token==1) {
                ray[i]=Baeyeoul[i];
            }
            else if(token==0) {
                if(ray[i-1]==ray[i-2]^ray[i-3]^ray[i-4]){ // calculate checksum bu ^(XOR) operator
                    pc.printf("Checksum is good!! value : %x,\r\n ",ray[i-1]);
            
                    if(ray[i-1]==0x41){
                        pc.printf("==> LED on \n");
                        led_on(); // execute led_on() func
                    }
                    else if(ray[i-1]==0x40) {
                        pc.printf("==> LED Off \n");
                        led_off(); // execute led_off() func
                    }
                    else if(ray[i-1]==0xB5){
                        pc.printf("==> dim up \n");
                        dim_up(); // execute dim_up() func
                    }
                    else if(ray[i-1]==0xA4){
                        pc.printf("==> dim down \n");
                        dim_down(); // execute dim_down() func
                    }
                    else if(ray[i-1]==0x42){
                        pc.printf("==> Buzzer \n");
                        Buzzer(); // execute Buzzer() func
                    }
                    else if(ray[i-1]==0x43){
                        pc.printf("==> Distance \n");
                        SONIC(); // execute SONIC() func
                    }
                }
                else {
                    pc.printf("Checksum error... retry");
                }
            }
        }
    }   
}