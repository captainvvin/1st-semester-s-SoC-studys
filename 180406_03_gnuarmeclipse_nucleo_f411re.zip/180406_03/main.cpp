#include "mbed.h"

void led_switch(void); // 아래에 선언된 함수를 사용하기위해
Ticker time_up;
DigitalOut MYLED(LED1);

void led_switch()
{
    MYLED = !MYLED; // led상태 반전
}
int main()
{
    time_up.attach(&led_switch,0.5); // 0.5초 주기로 점멸
    while(1) //sit in a loop doing nothing, waiting for Ticker interrupt
    {
    }
}

