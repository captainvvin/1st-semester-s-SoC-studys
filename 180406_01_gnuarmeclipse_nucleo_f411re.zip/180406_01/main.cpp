#include "mbed.h"

InterruptIn button(USER_BUTTON); // 입력을 유저버튼으로 사용하기위해
DigitalOut led(LED1);   // 보드의 LED 
DigitalOut flash(PA_4); // 브레드보드에 연결된 LED 

void ISR1() {
    led = !led; // 보드 LED를 반전 
}

int main() {
    button.rise(&ISR1); // 상승에지 버튼
    button.fall(&ISR1); // 하강에지 버튼
    while(1){
        flash = !flash; // flash 반전시킴 
        wait(0.5);      // 0.5초 주기로 상태를 반전
    }
}