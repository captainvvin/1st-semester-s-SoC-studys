#include "mbed.h"
#include "TextLCD.h"
#include "Serial.h"

Serial uart1(PA_9,PA_10); // set uart1 pin
TextLCD lcd(PC_10,PC_11,PC_12,PA_13,PA_14,PA_15); // set TextLCD pin
Serial pc(USBTX, USBRX); 
int distance1, distance2, distance3, total_distance;
int echo=0, i=0, correction=0;

int main() {
    int arr1[5] = {0xE1,0x01,0xA1,0x41,0xFF};
    int arr2[5] = {0xE1,0x01,0xA0,0x40,0xFF};
    int arr3[5] = {0xE1,0x01,0x55,0xB5,0xFF};
    int arr4[5] = {0xE1,0x01,0x44,0xA4,0xFF};
    int arr5[5] = {0xE1,0x02,0xA1,0x42,0xFF};
    int arr6[5] = {0xE1,0x03,0xA1,0x43,0xFF}; // put sending data by array
    while(1) {
        char c = pc.getc(); // put alphabet by keyboard
        if(c=='n'){ // if keyboard's input is 'n'
            for(i=0;i<5;i++){
                wait(0.1);
                pc.printf("%d ",uart1.putc(arr1[i])); // arr1 array's data is send to other board
            }
            pc.printf("\t");
        }
        else if(c=='f'){ // if keyboard's input is 'f'
            for(i=0;i<5;i++){
                wait(0.1);
                pc.printf("%d ",uart1.putc(arr2[i])); // arr2 array's data is send to other board
            }
            pc.printf("\t");
        }
        else if(c=='u'){ // if keyboard's input is 'u'
            for(i=0;i<5;i++){
                wait(0.1);
                pc.printf("%d ",uart1.putc(arr3[i])); // arr3 array's data is send to other board
            }
            pc.printf("\t");
        }
        else if(c=='d'){ // if keyboard's input is 'd'
            for(i=0;i<5;i++){
                wait(0.1);
                pc.printf("%d ",uart1.putc(arr4[i])); // arr4 array's data is send to other board
            }
            pc.printf("\t");
        }
        else if(c=='b'){ // if keyboard's input is 'b'
            for(i=0;i<5;i++){
                wait(0.1);
                pc.printf("%d ",uart1.putc(arr5[i])); // arr5 array's data is send to other board
            }
            pc.printf("\t");
        }
        else if(c=='r'){ // if keyboard's input is 'r'
            for(i=0;i<5;i++){
                wait(0.1);
                pc.printf("%d ",uart1.putc(arr6[i])); // arr6 array's data is send to other board
            }
            wait(0.1);
            
            for(i=0;i<3;i++){
                if(i==0){
                    distance1 = uart1.getc(); // save distance check data in distance1
                }
                else if(i==1){
                    distance2 = uart1.getc(); // save distance check data in distance2
                }
                else if(i==2){
                    distance3 = uart1.getc(); // save distance check data in distance3
                }
            }
            lcd.cls();
            lcd.locate(0,0);
            lcd.printf("%dcm %dcm %dcm", distance1, distance2, distance3); // print distance 1,2,3
            lcd.locate(0,1);
            total_distance = distance1+distance2+distance3;
            lcd.printf("sum = %dcm", total_distance);
            pc.printf("\t");
        }
        wait(0.1);
    }
}