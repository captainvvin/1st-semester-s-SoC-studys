#include "MPU6050.h"

MPU6050 mpu(PB_9,PB_8);
Serial pc(USBTX, USBRX);

float gry[3];
float angle[3];
float acc[3];

int main() {
    pc.printf("Initializing...\r\n");
    MPU6050 mpu6050(PB_9,PB_8);
    while(1) {
        mpu6050.getGyro(gry);
        mpu6050.getAcceleroAngle(angle);
        wait(0.2);
        pc.printf("Pitch = %f\t Roll = %f\t Yaw = %f\t\n",gry[0],gry[1],gry[2]);
        wait(0.2);
    }
}