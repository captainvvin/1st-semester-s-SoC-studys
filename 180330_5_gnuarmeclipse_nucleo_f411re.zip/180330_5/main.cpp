#include "mbed.h"
#include "TextLCD.h"

TextLCD lcd(PC_10,PC_11,PC_12,PA_13,PA_14,PA_15);
DigitalOut trigger(D2);
DigitalOut myled(D10);
DigitalOut myled2(D11);
DigitalIn echo(A1);
PwmOut mypwm(D6);                                 // 입출력 핀 설정

Serial pc(USBTX, USBRX); 

int distance = 0;
int correction = 0;
Timer sonar;

int main(){
    wait(10);
    pc.baud(115200); // 초당 펄스 115200 방출
    sonar.reset(); // 초음파 타이머 리셋
    sonar.start(); // 초음파 타이머 시작
    while (echo==2){}; //min software polling delay to read echo pin(pdf에 나온내용)
    myled2 =1; // led ON(상태판단을 위해)
    sonar.stop(); // 초음파 타이머 중지
    correction=sonar.read_us(); // 타이머 작동시간 읽음
    pc.printf("Approcimate software overhead timer delay is %d uS\n\r",correction);
    
    
    while(1){
        mypwm.period(0.1);
        trigger=1; // 트리거 Set
        myled=0; // 
        myled2=1; // 상태판단을 위한 led set
        sonar.reset(); // 초음파 타이머 리셋
        wait_us(10.0); // 트리거 핀의 센서에 10uS 폭의 펄스 보냄
        trigger = 0; // 트리거 리셋
        myled =1;
        
        while(echo ==0){}; // 에코가 high일때까지
        myled2 =! echo;
        sonar.start(); // 타이머 동작
        
        while(echo==1){}; //에코가 low일때까지 대기
        sonar.stop(); //타이머 중지
        distance = (sonar.read_us()-correction)/58.0; // 거리계산하는 식
        myled2 = 1;
        pc.printf("Distance = %d cm\n\n\r",distance); // pc에 거리 출력
        
        lcd.cls();
        lcd.printf("%d cm",distance); // lcd에 거리 출력
        wait(0.5f);
        if(15<distance<60) // 만약 거리가 15cm이상60cm이하이면
        {
            mypwm=abs(15-distance)*0.01f; // 거리에 따라 mypwm값을 변화시켜 밝기조절
        }
       wait(1);
    }
}