#include "mbed.h"

InterruptIn button(USER_BUTTON); // UserButton을 입력으로 
DigitalOut led(LED1); // led를 통해 digitalout
Timer debounce; // debounce타이머 작동시킴
void toggle(void); // 메인문뒤에있는 함수를 사용하기위해

int main()
{
    while(1) {
        debounce.start(); // 타이머작동
        button.rise(&toggle);
    }
}

void toggle() {
    if(debounce.read_ms()>1000) { // 1000ms동안 작동이 안되어야함
        led = !led; // 1초이상 지났으면 led반전 작동
        debounce.reset(); // 타이머 리셋시킴
    }
}