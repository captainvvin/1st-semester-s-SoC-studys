#include "mbed.h"
#include "SPI_TFT_ILI9341.h"
#include "stdio.h"
#include "string"
#include "Arial12x12.h"
#include "Arial24x23.h"
#include "Arial28x28.h"
#include "font_big.h"

Thread first_quarter; 
Thread second_quarter;
Thread third_quarter;
Thread fourth_quarter; // thread생성
Mutex stdio_mutex; // Mutex잠금,해제를 위
SPI_TFT_ILI9341 TFT(PC_12, PC_11, PC_10, PA_4, PA_10, PB_8,"TFT");

void quarter_1(){
        TFT.fillrect(120,160,240,320,Green);//1사분면
        TFT.fillrect(120,0,240,160,Cyan);//2사분면
        TFT.fillrect(0,0,120,160,White);//3사분면
        TFT.fillrect(0,160,120,320,Orange);//4사분면
}
void quarter_2() {
        TFT.fillrect(120,160,240,320,Purple);//1사분면
        TFT.fillrect(120,0,240,160,Black);//2사분면
        TFT.fillrect(0,0,120,160,Yellow);//3사분면
        TFT.fillrect(0,160,120,320,GreenYellow);//4사분면
}
void quarter_3(){
        TFT.fillrect(120,160,240,320,Navy);//1사분면
        TFT.fillrect(120,0,240,160,Red);//2사분면
        TFT.fillrect(0,0,120,160,White);//3사분면
        TFT.fillrect(0,160,120,320,Magenta);//4사분면
}
void quarter_4(){
        TFT.fillrect(120,160,240,320,DarkGreen);//1사분면
        TFT.fillrect(120,0,240,160,Olive);//2사분면
        TFT.fillrect(0,0,120,160,Maroon);//3사분면
        TFT.fillrect(0,160,120,320,Blue);//4사분면
}

void play(){
    while(1){
        stdio_mutex.lock(); // mutex잠금
        quarter_1();
        wait(1);
        quarter_2();
        wait(1);
        quarter_3();
        wait(1);
        quarter_4();
        wait(1);
        stdio_mutex.unlock(); // mutex잠금해제
    }
}

int main() {
    TFT.cls();
    while(1) {
        play();
    }
}
