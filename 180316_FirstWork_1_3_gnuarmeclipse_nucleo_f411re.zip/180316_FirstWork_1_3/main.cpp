#include "mbed.h"

PwmOut mypwm(PWM_OUT);

DigitalOut freq(D7);   // D7번 핀에서 출력을 발생시킵니다.

int main() {
    while(1) {
        freq = !freq;  // DigitalOut의 상태를 반전 시킵니다.
        wait_us(1250); // 0.00125s 를 us로 바꾸면 1250us입니다.
    }
}