#include "mbed.h"

DigitalOut myled(LED1);
Serial pc(SERIAL_TX, SERIAL_RX);

int main() {
    while(1) {
        myled = 1;
        wait(0.5);
        
        myled = 0;
        wait(0.5);
        
        myled.write(1);
        wait(0.5);
        
        myled.write(0);
        wait(0.5);
    }
}
