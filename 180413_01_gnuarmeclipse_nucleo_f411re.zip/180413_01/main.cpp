#include "mbed.h"

SPI spi (PA_7, PA_6, PA_5); // mosi , miso , sckl
DigitalOut chipSelect (PC_8); // ssel

Serial pc (USBTX, USBRX);

int main() {
    int valueToSendToSlave = 20; // Starting value only, this increments
    spi.format(8,3);// Setup : bit data, high steady state clock, 2nd edge
    spi.frequency(1000000); // 1MHz
    
    pc.printf("========================================\r\n");
    pc.printf("Press any key to start...\r\n");
    pc.getc(); // wait for keyboard
    
    int counter = 1;
    while (1) {
        pc.printf("%d Value to send = %d", counter++, valueToSendToSlave);
        
        chipSelect = 0; // Select device
        int dataFromSlave = spi.write(valueToSendToSlave);
        chipSelect = 1; // Deselect device
        
        pc.printf("  returns %d\r\n", dataFromSlave); // slave로 부터 받은 data를 출
        
        valueToSendToSlave++;
        
        wait(5); // Wait for 5 seconds for readability only
    }
}