#include "mbed.h"

Mutex stdio_mutex; // create Mutex
Thread t2;
Thread t3;
Thread t1;

void notify(const char* name, int state){
    stdio_mutex.lock(); // mutex lock
    printf("%s: %d\n\r", name, state); // USB TX,RX를 통해 프린트
    stdio_mutex.unlock(); // mutex unlock
}

void test_thread(void const *arge){
    while(true){
        notify((const char*)arge, 0); wait(1);
        notify((const char*)arge, 1); wait(1);
    }
}

int main(){
    t3.start(callback(test_thread,  (void*)"Th 3")); // Thread start & Print
    t2.start(callback(test_thread,  (void*)"Th 2"));
    test_thread((void*)"Th 1");
}