#include "mbed.h"
#include "TextLCD.h"

TextLCD lcd(PC_10, PC_11, PC_12, PA_13, PA_14, PA_15);

Thread Gawe;
Thread Bawe;
Thread Bo;

int count=0; // count값 초기화
void Gawe_thread(){
    while(true){
        if(count%3==0) {
            lcd.locate(0,0); // LCD 출력위치 지정
            lcd.printf("Ga we"); // 가위 출력
            wait(1);
            lcd.cls();
            count++;
        }
    }
}
void Bawe_thread(){
    while(true){
        if(count%3==1){
            lcd.locate(0,0);
            lcd.printf("Ba we"); // 바위 출력
            wait(1);
            lcd.cls();
            count++;
        }
    }
}

void Bo_thread(){
    while(true){
        if(count%3==2){
            lcd.locate(0,0);
            lcd.printf("Bo"); // 보 출력
            wait(1);
            lcd.cls();
            count++;
        }
    }
}

int main(){
    Gawe.start(Gawe_thread);
    Bawe.start(Bawe_thread);
    Bo.start(Bo_thread);
}