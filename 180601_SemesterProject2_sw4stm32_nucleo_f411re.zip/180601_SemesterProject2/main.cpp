/***** Draw 3D object with given vertices, triangular faces and angles of rotation******/
void draw_3D(Vertex * V, Triangle * T, nVertices, nTriangles, R)
{
    // sin and cos values
    sinX = sin_table( R.x ) / 255.0;
    sinY = sin_table( R.y ) / 255.0;
    sinZ = sin_table( R.z ) / 255.0;

    cosX = cos_table( R.x ) / 255.0;
    cosY = cos_table( R.y ) / 255.0;
    cosZ = cos_table( R.z ) / 255.0;

    // calculate the new coordinates of points
        for (i=0; i< nVertices; i++)
        {
            tempX = V[i].x;
            tempY = V[i].y;
            tempZ = V[i].z;

            // store previous coordinates
            old_points[i] = new_points[i];

            // rotation on X axis
            py = tempY * cosX - tempZ * sinX;
            pz = tempY * sinX + tempZ * cosX;
            tempY =py; tempZ = pz;

            // rotation on Z axis
            px = tempX * cosZ - tempY * sinZ;
            py = tempX * sinZ + tempY * cosZ;
            tempX = px; tempY = py;

            // rotation on Y axis
            px = tempX * cosY - tempZ * sinY;
            pz = tempX * sinY + tempZ * cosY;

            // save the screen coordinates
            new_points[i].x = px * SCALE_FACTOR + OFFSETX;
            new_points[i].y = py * SCALE_FACTOR + OFFSETY;
        }
        // erase previous triangles
        for (i=0; i< nTriangles; i++)
        {
            if( !Backface( old_points[T[i].A], old_points[T[i].B], old_points[T[i].C] ) )
                fill_triangle(old_points[T[i].A], old_points[T[i].B], old_points[T[i].C], BG_COLOR);
        }
        // lcd plot new triangles
        for (i=0; i< nTriangles; i++)
        {
            if( !Backface( new_points[T[i].A], new_points[T[i].B], new_points[T[i].C] ) )
                fill_triangle(new_points[T[i].A], new_points[T[i].B], new_points[T[i].C], T[i].color);
        }
}
