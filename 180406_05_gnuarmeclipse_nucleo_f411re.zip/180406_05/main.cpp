#include "mbed.h"

DigitalOut TestLED(PA_4); // 출력핀 설정
Serial pc(USBTX, USBRX); // PC입력 사용을 위해 설정해줌

int main () {
    TestLED = 0;
    
    while(1) {
        pc.putc(pc.getc()); // 문자가 입력이 되면
        TestLED = !TestLED; // 상태 반전된다.
    }
}