#include "mbed.h"
#include "TextLCD.h"
typedef char U8; 

TextLCD lcd(PC_10, PC_11, PC_12,PA_13,PA_14,PA_15); //PIN 번호 설정 
Serial pc(SERIAL_TX,SERIAL_RX);
Serial uart1(PA_9,PA_10); //uart1 포트 설정
Serial uart2(PB_6,PB_7);  //uart2 포트 설정 

void put_string(U8 *string, U8 data_num);

int main(){
        lcd.cls();
        while(1){
            U8 test_string[] = " bin GWANG \n";  // 입력 문자열 
            lcd.locate(0,0);                       // 첫 번째 줄에 출력
            put_string(test_string, strlen(test_string)); 
            for(int i=0;test_string[i]; ++i){
                if((test_string[i]>='a')&&(test_string[i]<='z')){
                    test_string[i] = test_string[i]-'a'+'A';         // 대문자로 바꿈 
                }   
                else{
                    if((test_string[i]>='A')&&(test_string[i]<='Z')){
                        test_string[i] = test_string[i]-'A'+'a';      // 소문자로 바꿈 
                    }          
                }
            }
            lcd.locate(0,1);    // 두번 째 줄에 출력 
            put_string(test_string, strlen(test_string));
        }
}

void put_string(U8 *string, U8 data_num){  //문자를 반복하는 함수 
    for(;data_num;data_num--){
        uart1.putc(*string);
        lcd.printf("%c",uart2.getc());
        string++; 
    }
}