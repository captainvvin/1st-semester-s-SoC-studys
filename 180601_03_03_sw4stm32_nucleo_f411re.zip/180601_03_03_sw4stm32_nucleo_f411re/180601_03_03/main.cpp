#include "mbed.h"
#include "TextLCD.h"

Semaphore two_slots(1); // 세마포 카운팅 1
Thread t2;
Thread t3;

TextLCD lcd(PC_10, PC_11, PC_12, PA_13, PA_14, PA_15);

void test_thread(void const *name){
    while(true){
        two_slots.wait();
        lcd.locate(0,0); // LCD 출력위치 지정
        lcd.printf("%s\n\r", (const char*)name);
        wait(1);
        lcd.cls();
        two_slots.release();
    }
}

int main(){
    t2.start(callback(test_thread, (void *)"Ga we")); // t2에 test_thread실행 후 가위출력
    t3.start(callback(test_thread, (void *)"Ba we")); // t3에 test_thread실행 후 바위출력
    test_thread((void*)"Bo"); // test_thread실행 후 보출력
}