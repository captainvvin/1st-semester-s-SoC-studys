#include "mbed.h"

SPISlave device(PA_7, PA_6, PA_5, PA_15); // mosi, miso, sckl, ssel

Serial pc(USBTX, USBRX); // pc와의 통신을 위

int main(){
    
    int counter = 1;
    
    device.format(8,3); // Setup : bit data, high steady state clock, 2nd edge
    device.frequency(1000000); // 1MHz
    
    int reply = 99; // reply를 99로 inicialize
    device.reply(reply);   // Prime SPI with first reply
    device.reply(reply);   // Prime SPI with first reply, again
    
    pc.printf("========================================\r\n");
    pc.printf("Startup Next reply will be %d\r\n", reply);
    
    while(1){
        if (device.receive()){
            int valueFromMaster = device.read(); // Master의 데이터를 read
            pc.printf("%d Something rxvd, and should have replied with %d\r\n",counter++,reply);
            device.reply(++reply);
            pc.printf("     Received value from Master (%d) Next reply will be %d\r\n",valueFromMaster,reply);
            }
        }
}

