#include "mbed.h"

typedef signed char S8; // range :  -128~127
typedef        char U8; // range :  0 ~ 255(unsigned)
typedef          short S16; // range : -32,768 ~ -32,767 (signed)
typedef unsigned short U16; // range : 0 ~ 65,535
typedef          int S32; // range : -2,147,483,648 ~ 2,147,483,647
typedef unsigned int U32; // range : 0 ~ 4,294,967,295 
typedef          long S64; //range : -9,223,372,036,854,775,808~9,223,372,036,854,775,807
typedef unsigned long U64; //range : 0 ~ 18,446,744,073,709,709,551,615

Serial pc(SERIAL_TX,SERIAL_RX);
Serial uart1(PA_9, PA_10);
Serial uart2(PB_6, PB_7);

DigitalOut MYLED(LED1);

int main(){
    while(1){
        uart1.putc('h'); // h출력
        pc.putc(uart2.getc()); // uart2의 입력받은 내용을 출력
        uart1.putc('i'); // i출력
        pc.putc(uart2.getc()); 
        pc.putc('\n');
        
        uart2.putc('o'); // o출력
        pc.putc(uart1.getc()); // uart1의 입력받은 내용을 출력
        uart2.putc('k'); // k출력
        pc.putc(uart1.getc());
        pc.putc('\n');
        MYLED = !MYLED; // MYLED상태 반전
        wait(1); // 1초대기
    }
}
