#include "mbed.h"

PwmOut mypwm(PWM_OUT);

DigitalOut freq(D7);   // D7번 핀에서 출력을 발생시킵니다.

int main() {
    while(1) {
        freq = !freq;  // DigitalOut의 상태를 반전 시킵니다.
        wait(0.00125); // 400HZ를 나타내기위해 했습니다. 0.0125초동안 상태 유지를 하고
                       // 반전이 되면 1주기의 상태가 0.025가 되기 때문에 400Hz가 됩니다.
    }
}