#include "mbed.h"

PwmOut mypwm(PWM_OUT);

DigitalOut freq(D7);   // D7번 핀에서 출력을 발생시킵니다.

int main() {
    while(1) {
        freq = !freq;  // DigitalOut의 상태를 반전 시킵니다.
        wait_ms(1);    // wait_ms()는 자료형을 int형으로만 받기때문에
        wait(0.00025); // 추가적인 값은 wait()함수로 처리했습니다.
    }
}