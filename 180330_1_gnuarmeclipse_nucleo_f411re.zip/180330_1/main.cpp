#include "mbed.h"

Serial pc(USBTX, USBRX);

AnalogIn Ain(PB_0);

float ADCdata1, ADCdata2;

unsigned short ADCdata3;

int main() {
    pc.baud(9600); // 초당 9600펄스 방출
    pc.printf("ADC Data Values... \n\r"); // 프린트문 출력
    
    while(1){
        ADCdata1 = Ain;
        ADCdata2 = Ain.read();
        ADCdata3 = Ain.read_u16();
        pc.printf("ADCdata1 = %f \n\r",ADCdata1);
        pc.printf("ADCdata2 = %f \n\r",ADCdata2);
        pc.printf("ADCdata3 = %f \n\r",ADCdata3);
        wait(0.5);   
    }    
}