#include "mbed.h"

Timeout Response;
Timer T; // 타이머 선언
DigitalIn InputButton(USER_BUTTON); // 보드의 유저버튼으 입력으로 사용 
DigitalOut led1(LED1);              // 보드의 LED 출력
DigitalOut led2(PA_4);              // LED의 출력  

void blink() 
{
    T.start(); // 타이머 스타트
    while(T.read()<3) // 3초
    {
        led2 = !led2; // LED 반전 
        wait(0.5);    // 0.5초 주기로 
    }
    T.stop(); // 타이머 정지 
    T.reset(); // 타이머 리셋
}

int main () {
    while(1)                    
    {
        if(InputButton==0) // 유저버튼 On
        {
            led1= !led1; 
            Response.attach(&blink,2.0);  // 2초간의 타임아웃
        }
    led2 = 1; //blink 함수 실행 후 LED2 off
    }
}


