#include "mbed.h"
#include "TextLCD.h"

Mutex stdio_mutex; // mutex 생성
Thread t2;
Thread t3;
Thread t1;

TextLCD lcd(PC_10, PC_11, PC_12, PA_13, PA_14, PA_15);

int count = 0; // count 0으로 초기화

void notify(const char* name){
    stdio_mutex.lock(); // mutex잠금
    lcd.locate(0,0); // LCD출력위치 지
    lcd.printf("%s\n\r", name);
    stdio_mutex.unlock(); // mutex해제
}

void test_thread(void const *arge){
        notify((const char*)arge); wait(1);
        notify((const char*)arge); wait(1);
}

int main(){
    while(true){
        if(count%3==0){ // count를 3으로 나누었을 때 나머지가 0이면
            t1.start(callback(test_thread, (void*)"Ga we")); // t1에 test_thread실행 후 Gawe출력
            wait(1);
            lcd.cls();
            count++;
        }
        else if(count%3==1){ // count를 3으로 나누었을 때 나머지가 1이면
            t2.start(callback(test_thread, (void*)"Ba we")); // t2에 test_thread실행 후 Bawe출력
            wait(1);
            lcd.cls();
            count++;
        }
        else if(count%3==2){ // count를 3으로 나누었을 때 나머지가 2이면
            t3.start(callback(test_thread, (void*)"Bo")); // t3에 test_thread실행 후 Bo출력
            wait(1);
            lcd.cls();
            count++;
        }
    }
}