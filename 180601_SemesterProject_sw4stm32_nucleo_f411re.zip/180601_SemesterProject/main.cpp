#include "stdio.h"
#include "mbed.h"
#include "SPI_TFT_ILI9341.h"
#include "string"
#include "Arial12x12.h"
#include "Arial24x23.h"
#include "Arial28x28.h"
#include "font_big.h"
#include "MPU6050"

SPI_TFT_ILI9341 TFT(PC_12, PC_11, PC_10 , PA_15, PA_9, PB_8,"TFT"); // mosi, miso, sclk, cs, reset, dc SPI1을 사용

float tx, nx, p;
float ty, ny, py;
float rot, rotx, roty, rotz, rotxx, rotyy, rotzz, rotxxx, rotyyy, rotzzz; //initialize values
int i; //0 to 360 degree
int fl, scale;
int wireframe[12][3];

int originx = 120; //x-point of things
int originy = 160; //y-point of things

int front_depth = 40;
int back_depth = -40;

//Store cube vertices
int cube_vertex[8][3] = {
    { -40, -40, front_depth},{40, -40, front_depth},{40, 40, front_depth},{ -40, 40, front_depth},
    { -40, -40, back_depth},{40, -40, back_depth},{40, 40, back_depth},{ -40, 40, back_depth}
};

int fd = 0; //0=orthographic
void draw_wireframe(void){
    TFT.line(wireframe[0][0], wireframe[0][1], wireframe[1][0], wireframe[1][1],White);
    TFT.line(wireframe[1][0], wireframe[1][1], wireframe[2][0], wireframe[2][1],White);
    TFT.line(wireframe[2][0], wireframe[2][1], wireframe[3][0], wireframe[3][1],White);
    TFT.line(wireframe[3][0], wireframe[3][1], wireframe[0][0], wireframe[0][1],White);

    TFT.line(wireframe[4][0], wireframe[4][1], wireframe[5][0], wireframe[5][1],White);
    TFT.line(wireframe[5][0], wireframe[5][1], wireframe[6][0], wireframe[6][1],White);
    TFT.line(wireframe[6][0], wireframe[6][1], wireframe[7][0], wireframe[7][1],White);
    TFT.line(wireframe[7][0], wireframe[7][1], wireframe[4][0], wireframe[4][1],White);

    TFT.line(wireframe[0][0], wireframe[0][1], wireframe[4][0], wireframe[4][1],White);
    TFT.line(wireframe[1][0], wireframe[1][1], wireframe[5][0], wireframe[5][1],White);
    TFT.line(wireframe[2][0], wireframe[2][1], wireframe[6][0], wireframe[6][1],White);
    TFT.line(wireframe[3][0], wireframe[3][1], wireframe[7][0], wireframe[7][1],White);
}

void draw_wireframe1(void){
    TFT.line(wireframe[0][0], wireframe[0][1], wireframe[1][0], wireframe[1][1],Black);
    TFT.line(wireframe[1][0], wireframe[1][1], wireframe[2][0], wireframe[2][1],Black);
    TFT.line(wireframe[2][0], wireframe[2][1], wireframe[3][0], wireframe[3][1],Black);
    TFT.line(wireframe[3][0], wireframe[3][1], wireframe[0][0], wireframe[0][1],Black);

    TFT.line(wireframe[4][0], wireframe[4][1], wireframe[5][0], wireframe[5][1],Black);
    TFT.line(wireframe[5][0], wireframe[5][1], wireframe[6][0], wireframe[6][1],Black);
    TFT.line(wireframe[6][0], wireframe[6][1], wireframe[7][0], wireframe[7][1],Black);
    TFT.line(wireframe[7][0], wireframe[7][1], wireframe[4][0], wireframe[4][1],Black);

    TFT.line(wireframe[0][0], wireframe[0][1], wireframe[4][0], wireframe[4][1],Black);
    TFT.line(wireframe[1][0], wireframe[1][1], wireframe[5][0], wireframe[5][1],Black);
    TFT.line(wireframe[2][0], wireframe[2][1], wireframe[6][0], wireframe[6][1],Black);
    TFT.line(wireframe[3][0], wireframe[3][1], wireframe[7][0], wireframe[7][1],Black);
}


void loop(void){//Formula
//picture loop
    for (int angle = 0; angle <= 360; angle = angle + 1) {
        for (int i = 0; i < 8; i++) {
            rot = angle * 0.0174532; //0.0174532 = one degree
//rotateY
            rotz = cube_vertex[i][2] * cos(rot) - cube_vertex[i][0] * sin(rot);
            rotx = cube_vertex[i][2] * sin(rot) + cube_vertex[i][0] * cos(rot);
            roty = cube_vertex[i][1];
//rotateX
            rotyy = roty * cos(rot) - rotz * sin(rot);
            rotzz = roty * sin(rot) + rotz * cos(rot);
            rotxx = rotx;
//rotateZ
            rotxxx = rotxx * cos(rot) - rotyy * sin(rot);
            rotyyy = rotxx * sin(rot) + rotyy * cos(rot);
            rotzzz = rotzz;
//orthographic projection
            rotxxx = rotxxx + originx;
            rotyyy = rotyyy + originy;
//store new vertices values for wireframe drawing
            wireframe[i][0] = rotxxx;
            wireframe[i][1] = rotyyy;
            wireframe[i][2] = rotzzz;
        }
        draw_wireframe();//rotate things
        draw_wireframe1();//color to black
    }
}

int main(){
    while(1){
        loop();
    }
} 