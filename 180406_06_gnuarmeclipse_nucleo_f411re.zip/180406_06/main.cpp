#include "mbed.h"

DigitalOut TestLED(PA_4);
Serial pc(USBTX, USBRX);
Ticker T1;

void attime(){
    TestLED = !TestLED; // LED상태 반전
}
    
int main () {
    T1.attach (&attime, 0.5); // 원래 깜빡거리고있다.
    
    while(1)
    {
        pc.putc(pc.getc()); // 입력이있으면
        TestLED = !TestLED; // 깜빡거린다.
    }
}