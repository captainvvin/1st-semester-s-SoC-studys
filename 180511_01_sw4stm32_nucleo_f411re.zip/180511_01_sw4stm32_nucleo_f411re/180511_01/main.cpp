#include "mbed.h"

DigitalOut B_LED(PC_10);
DigitalOut G_LED(PC_11);
DigitalOut R_LED(PC_12);
DigitalOut led1(LED1);

InterruptIn SW(USER_BUTTON);
Timer debounce;

Thread blue;
Thread green;
Thread red;

void bled_thread()
{
    while(true){
        wait(0.5);
        B_LED = !B_LED;
    }
}

void gled_thread()
{
    while(true){
        wait(1);
        G_LED = !G_LED;
    }
}

void rled_thread()
{
    while(true){
        wait(2);
        R_LED = !R_LED;
    }
}

void toggle()
{
    if(debounce.read_ms()>5){
        led1 = !led1;
        debounce.reset();
    }
}

int main()
{
    blue.start(bled_thread);
    green.start(gled_thread);
    red.start(rled_thread);
    
    debounce.start();
    SW.rise(&toggle);
}